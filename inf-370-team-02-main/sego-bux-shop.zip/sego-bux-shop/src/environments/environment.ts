export const environment = {
  production: false,
  emailJsUserId: 'szdFF1Kfu0BD53aWB',
  emailJsServiceId: 'service_tafmopo',
  emailJsTemplateId: 'template_a4v3v32'
};
