import { Routes } from '@angular/router';
import { AuthGuard } from './services/auth.guard';
import { RoleGuard } from './services/role.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./pages/landing/landing.component').then(m => m.LandingComponent)
  },
  {
    path: 'register',
    loadComponent: () =>
      import('./auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'login',
    loadComponent: () =>
      import('./auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'products',
    loadComponent: () =>
      import('./shop/product-list.component').then(m => m.ProductListComponent)
  },
  {
    path: 'contact',
    loadComponent: () =>
      import('./contact/contact.component').then(m => m.ContactComponent)
  },
  {
    path: 'profile',
    loadComponent: () =>
      import('./profile/customer-profile/customer-profile.component').then(m => m.CustomerProfileComponent),
    canActivate: [AuthGuard]
  },

  // ✅ ADMIN ROUTES
  {
    path: 'admin',
    loadComponent: () =>
      import('./admin/admin-dashboard/admin-dashboard.component')
        .then(m => m.DashboardComponent),
    canActivate: [RoleGuard],
    data: { roles: ['Employee', 'Admin', 'Manager'] },
    children: [
      {
        path: 'products',
        loadComponent: () =>
          import('./admin/manage-products.component').then(m => m.ManageProductsComponent)
      },
      {
        path: 'product-types',
        loadComponent: () =>
          import('./admin/manage-product-types.component').then(m => m.ManageProductTypesComponent)
      },
      {
        path: 'categories',
        loadComponent: () =>
          import('./admin/manage-categories.component').then(m => m.ManageCategoriesComponent)
      },
      {
        path: 'employees',
        loadComponent: () =>
          import('./admin/manage-employees/manage-employees.component').then(m => m.ManageEmployeesComponent)
      }
    ]
  }
];
