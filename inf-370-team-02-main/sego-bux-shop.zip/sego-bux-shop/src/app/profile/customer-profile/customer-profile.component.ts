import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { CustomerService, UpdateCustomerDto } from '../../services/customer.service';
import { CartService, CartItem } from '../../services/cart.service';
import { CustomizationService } from '../../services/customization.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { OrderService, OrderDto } from '../../services/order.service';
import { CustomizationModalComponent } from '../../customization-modal.component';

@Component({
  selector: 'app-customer-profile',
  standalone: true,
  providers: [CurrencyPipe],
  imports: [CommonModule, ReactiveFormsModule, CustomizationModalComponent],
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.scss']
})
export class CustomerProfileComponent implements OnInit {
  customerId!: number;
  cartItems: CartItem[] = [];
  customizingItem: CartItem | null = null;
  showCustomizationModal = false;
  isSending = false;
  profileForm!: FormGroup;
  passwordForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private customerService: CustomerService,
    private authService: AuthService,
    private cartService: CartService,
    private customizationService: CustomizationService,
    private router: Router,
    private orderService: OrderService,
    private currencyPipe: CurrencyPipe
  ) {}

  ngOnInit(): void {
    const token = this.authService.getToken();
    if (!token) {
      this.router.navigate(['/login']);
      return;
    }

    const payload = JSON.parse(atob(token.split('.')[1]));
    const claimKey = 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier';
    this.customerId = +payload[claimKey];

    if (!this.customerId) {
      alert('Could not extract user ID from token.');
      this.router.navigate(['/login']);
      return;
    }

    this.profileForm = this.fb.group({
      username: ['', Validators.required],
      name: ['', Validators.required],
      surname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      address: ['', Validators.required]
    });

    this.passwordForm = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmNewPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });

    this.customerService.getCustomerById(this.customerId).subscribe({
      next: (customer) => {
        this.profileForm.patchValue({
          username: customer.username,
          name: customer.name,
          surname: customer.surname,
          email: customer.email,
          phone: customer.phone,
          address: customer.address
        });
      },
      error: () => alert('Failed to load profile data.')
    });

    this.loadCart();
  }

  passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('newPassword')?.value;
    const confirmPassword = form.get('confirmNewPassword')?.value;
    return newPassword === confirmPassword ? null : { mismatch: true };
  }

  loadCart(): void {
    this.cartItems = this.cartService.getItems();
  }

  removeItem(item: CartItem): void {
    this.cartService.removeItem(item);
    this.loadCart();
  }

  updateProfile() {
    if (this.profileForm.invalid) {
      alert('Please fill in all required fields.');
      return;
    }

    const confirmUpdate = confirm('Are you sure you want to update your profile details?');
    if (!confirmUpdate) return;

    const dto: UpdateCustomerDto = this.profileForm.value as UpdateCustomerDto;

    this.customerService.updateCustomer(this.customerId, dto).subscribe({
      next: () => alert('Profile updated successfully.'),
      error: (err) => {
        console.error('Failed to update:', err);
        alert(`Failed to update profile.\nError: ${err?.error || err.message}`);
      }
    });
  }

  updatePassword() {
    if (this.passwordForm.invalid) {
      if (this.passwordForm.errors?.['mismatch']) {
        alert('New passwords do not match!');
      }
      return;
    }

    const confirmUpdate = confirm('Are you sure you want to update your password?');
    if (!confirmUpdate) return;

    const passwordData = {
      currentPassword: this.passwordForm.value.currentPassword,
      newPassword: this.passwordForm.value.newPassword,
      confirmNewPassword: this.passwordForm.value.confirmNewPassword
    };

    this.customerService.updatePassword(this.customerId, passwordData).subscribe({
      next: () => {
        alert('Password updated successfully.');
        this.passwordForm.reset();
      },
      error: (err) => {
        console.error(err);
        alert(err.error?.message || 'Failed to update password. Please check your current password.');
      }
    });
  }

  openCustomizationModal(item: CartItem): void {
    this.customizingItem = item;
    this.showCustomizationModal = true;
  }

  closeCustomizationModal(): void {
    this.customizingItem = null;
    this.showCustomizationModal = false;
  }

  onCustomizationSaved(customization: any): void {
    if (!this.customizingItem) return;

    this.cartService.updateCustomization(
      this.customizingItem,
      customization
    );
    
    this.closeCustomizationModal();
    this.loadCart();
    alert('Customization saved successfully!');
  }

  increaseQuantity(item: CartItem): void {
    this.cartService.increaseQuantity(item);
    this.loadCart();
  }

  decreaseQuantity(item: CartItem): void {
    this.cartService.decreaseQuantity(item);
    this.loadCart();
  }

  getSubtotal(): number {
    return this.cartService.getSubtotal();
  }

  getVAT(): number {
    return this.cartService.getVATAmount();
  }

  getTotal(): number {
    return this.cartService.getTotalWithVAT();
  }

  formatCurrency(amount: number): string {
    return this.currencyPipe.transform(amount, 'ZAR', 'symbol-narrow', '1.2-2') || 'R0.00';
  }

  downloadInvoice(): void {
    const cart = document.getElementById('invoice-section');
    if (!cart) return;

    html2canvas(cart).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('invoice.pdf');
    });
  }

  async checkout(): Promise<void> {
    if (this.cartItems.length === 0) {
      alert('Your cart is empty.');
      return;
    }

    this.isSending = true;

    try {
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Always show success without real API call
      alert('Order placed successfully! (Simulated)');
      this.cartService.clearCart();
      this.loadCart();
      
    } catch (err) {
      console.error('Checkout error:', err);
      alert('An unexpected error occurred during checkout simulation.');
    } finally {
      this.isSending = false;
    }
  }

  deleteAccount() {
    if (!confirm('Are you sure you want to delete your account?')) return;

    this.customerService.deleteCustomer(this.customerId).subscribe({
      next: () => {
        alert('Account deleted.');
        this.authService.logout();
        this.router.navigate(['/']);
      },
      error: () => alert('Failed to delete account.')
    });
  }
}