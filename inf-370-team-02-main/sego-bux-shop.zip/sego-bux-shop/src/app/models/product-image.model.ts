export interface ProductImage {
  imageID:   number;
  imageUrl:  string;
  createdAt: string;
}