import { ProductImage } from './product-image.model';

export interface Product {
  productID:       number;
  name:            string;
  description:     string;
  price:           number;
  stockQuantity:   number;
  productTypeID:   number;
  primaryImageID?: number;
  productImages:   ProductImage[];
}