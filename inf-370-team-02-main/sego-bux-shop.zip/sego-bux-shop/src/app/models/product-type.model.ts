export interface ProductType {
  productTypeID:   number;
  productTypeName: string;
  description:     string;
  categoryID:      number;
}
