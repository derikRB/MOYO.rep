import { Component, OnInit }         from '@angular/core';
import { CommonModule }              from '@angular/common';
import { FormsModule }               from '@angular/forms';
import { ProductService }            from '../services/product.service';
import { CartService }               from '../services/cart.service';
import { Product }                   from '../models/product.model';
import { ProductImage }              from '../models/product-image.model';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  products:         Product[] = [];
  filteredProducts: Product[] = [];

  constructor(
    public productService: ProductService,
    private cartService:   CartService
  ) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe(data => {
      data.forEach(p => p.productImages ||= []);
      this.products         = this.filteredProducts = data;
    });
  }

  /** pick the primaryImageID entry, else first, else logo */
  getImageUrl(p: Product): string {
    // if primaryImageID is set, find that image
    if (p.primaryImageID) {
      const primary = p.productImages
        .find(img => img.imageID === p.primaryImageID);
      if (primary) {
        return this.productService.imageFullUrl(primary);
      }
    }
    // fallback to first
    if (p.productImages.length) {
      return this.productService.imageFullUrl(p.productImages[0]);
    }
    // final fallback
    return 'assets/logo.png';
  }

  addToCart(p: Product): void {
    this.cartService.addToCart({
      productId: p.productID,
      name:      p.name,
      price:     p.price,
      quantity:  1,
      imageUrl:  this.getImageUrl(p)
    });
  }
}
