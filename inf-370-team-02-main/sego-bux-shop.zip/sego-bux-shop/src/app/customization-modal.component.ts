import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-customization-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './customization-modal.component.html',
  styleUrls: ['./customization-modal.component.scss']
})
export class CustomizationModalComponent {
  @Input() product: any;
  @Output() save = new EventEmitter<any>();
  @Output() close = new EventEmitter<void>();

  customization = {
    template: '',
    customText: '',
    font: 'Arial',
    fontSize: 16,
    color: '#000000'
  };

  templates = ['Template1', 'Template2', 'Template3'];

  onSave() {
    if (!this.customization.template || !this.customization.customText) {
      alert('Please fill in all required fields');
      return;
    }
    this.save.emit(this.customization);
  }

  onClose() {
    this.close.emit();
  }
}