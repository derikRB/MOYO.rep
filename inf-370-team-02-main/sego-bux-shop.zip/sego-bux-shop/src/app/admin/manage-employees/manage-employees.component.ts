import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService, Employee } from '../../services/admin.service';

@Component({
  selector: 'app-manage-employees',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-employees.component.html',
  styleUrls: ['./manage-employees.component.scss']
})
export class ManageEmployeesComponent implements OnInit {
  employees: Employee[] = [];
  searchTerm = '';

  form = {
    emailOrUsername: '',
    password: ''
  };

  editForm: Employee = {
    employeeID: 0,
    username: '',
    email: '',
    role: ''
  };

  editing = false;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees() {
    this.adminService.getEmployees().subscribe((data: Employee[]) => {
      this.employees = data;
    });
  }

  registerEmployee() {
    this.adminService.registerEmployee(this.form).subscribe(() => {
      this.form = { emailOrUsername: '', password: '' };
      this.loadEmployees();
    });
  }

  deleteEmployee(id: number) {
    if (confirm('Are you sure you want to delete this employee?')) {
      this.adminService.deleteEmployee(id).subscribe(() => this.loadEmployees());
    }
  }

  setEdit(employee: Employee) {
    this.editing = true;
    this.editForm = { ...employee };
  }

  updateEmployee() {
    this.adminService.updateEmployee(this.editForm.employeeID, this.editForm).subscribe(() => {
      this.editing = false;
      this.loadEmployees();
    });
  }

  cancelEdit() {
    this.editing = false;
    this.editForm = { employeeID: 0, username: '', email: '', role: '' };
  }

  searchEmployees() {
    if (!this.searchTerm.trim()) {
      this.loadEmployees();
      return;
    }

    this.adminService.searchEmployees(this.searchTerm).subscribe((data: Employee[]) => {
      this.employees = data;
    });
  }
}
