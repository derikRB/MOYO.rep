import { Component, OnInit } from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { AdminService }  from '../services/admin.service';

@Component({
  selector: 'app-manage-categories',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-categories.component.html',
  styleUrls: ['./manage-categories.component.scss']
})
export class ManageCategoriesComponent implements OnInit {
  categories: any[] = [];

  form: any = {
    categoryName: '',
    description:  ''
  };

  isEditMode       = false;
  editingCategoryID: number | null = null;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadCategories();
  }

  loadCategories() {
    this.adminService.getCategories()
      .subscribe(data => this.categories = data);
  }

  addCategory() {
    this.adminService.addCategory(this.form)
      .subscribe(() => {
        this.resetForm();
        this.loadCategories();
      });
  }

  editCategory(c: any) {
    this.isEditMode = true;
    this.editingCategoryID = c.categoryID;
    this.form = {
      categoryName: c.categoryName,
      description:  c.description
    };
  }

  updateCategory() {
    if (this.editingCategoryID == null) return;
    this.adminService.updateCategory(this.editingCategoryID, this.form)
      .subscribe(() => {
        this.resetForm();
        this.loadCategories();
      });
  }

  deleteCategory(id: number) {
    this.adminService.deleteCategory(id)
      .subscribe(() => this.loadCategories());
  }

  resetForm() {
    this.form = {
      categoryName: '',
      description:  ''
    };
    this.isEditMode = false;
    this.editingCategoryID = null;
  }
}
