import { Component, OnInit } from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { AdminService }  from '../services/admin.service';

@Component({
  selector: 'app-manage-product-types',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-product-types.component.html',
  styleUrls: ['./manage-product-types.component.scss']
})
export class ManageProductTypesComponent implements OnInit {
  productTypes: any[] = [];
  categories:   any[] = [];

  form: any = {
    productTypeName: '',
    description:     '',
    categoryID:      null
  };

  isEditMode       = false;
  editingProductTypeID: number | null = null;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadProductTypes();
    this.loadCategories();
  }

  loadProductTypes() {
    this.adminService.getProductTypes()
      .subscribe(data => this.productTypes = data);
  }

  loadCategories() {
    this.adminService.getCategories()
      .subscribe(data => this.categories = data);
  }

  addProductType() {
    this.adminService.addProductType(this.form)
      .subscribe(() => {
        this.resetForm();
        this.loadProductTypes();
      });
  }

  editProductType(pt: any) {
    this.isEditMode = true;
    this.editingProductTypeID = pt.productTypeID;
    this.form = {
      productTypeName: pt.productTypeName,
      description:     pt.description,
      categoryID:      pt.categoryID
    };
  }

  updateProductType() {
    if (this.editingProductTypeID == null) return;
    this.adminService.updateProductType(this.editingProductTypeID, this.form)
      .subscribe(() => {
        this.resetForm();
        this.loadProductTypes();
      });
  }

  deleteProductType(id: number) {
    this.adminService.deleteProductType(id)
      .subscribe(() => this.loadProductTypes());
  }

  resetForm() {
    this.form = {
      productTypeName: '',
      description:     '',
      categoryID:      null
    };
    this.isEditMode = false;
    this.editingProductTypeID = null;
  }
}
