import { Component, OnInit }    from '@angular/core';
import { CommonModule }         from '@angular/common';
import { FormsModule }          from '@angular/forms';
import { AdminService }         from '../services/admin.service';
import { Product }              from '../models/product.model';
import { ProductImage }         from '../models/product-image.model';
@Component({
  selector: 'app-manage-products',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-products.component.html',
  styleUrls: ['./manage-products.component.scss']
})
export class ManageProductsComponent implements OnInit {
  products: Product[]     = [];
  productTypes: any[]     = [];

  form: any = {
    name:           '',
    description:    '',
    price:          0,
    stockQuantity:  0,
    productTypeID:  null,
    primaryImageID: null
  };

  selectedFiles?: FileList;
  currentImages: ProductImage[] = [];
  selectedPrimaryImageId: number | null = null;

  isEditMode = false;
  editingProductId: number | null = null;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadProducts();
    this.loadProductTypes();
  }

  loadProducts() {
    this.adminService.getProducts()
      .subscribe(data => this.products = data);
  }

  loadProductTypes() {
    this.adminService.getProductTypes()
      .subscribe(types => this.productTypes = types);
  }

  onFileChange(e: Event) {
    const input = e.target as HTMLInputElement;
    this.selectedFiles = input.files || undefined;
  }

  addProduct() {
    this.adminService.addProduct(this.form)
      .subscribe(newProd => {
        if (this.selectedFiles) {
          this.adminService
            .uploadProductImages(newProd.productID, this.selectedFiles)
            .subscribe(() => this.selectedFiles = undefined);
        }
        this.resetForm();
        this.loadProducts();
      });
  }

  editProduct(p: Product) {
    this.isEditMode       = true;
    this.editingProductId = p.productID;
    this.form = {
      name:           p.name,
      description:    p.description,
      price:          p.price,
      stockQuantity:  p.stockQuantity,
      productTypeID:  p.productTypeID,
      primaryImageID: p.primaryImageID ?? null
    };
    this.currentImages          = p.productImages;
    this.selectedPrimaryImageId = p.primaryImageID ?? null;
  }

  updateProduct() {
    if (!this.editingProductId) return;
    const dto = {
      ...this.form,
      primaryImageID: this.selectedPrimaryImageId
    };
    this.adminService.updateProduct(this.editingProductId, dto)
      .subscribe(() => {
        if (this.selectedFiles) {
          this.adminService
            .uploadProductImages(this.editingProductId!, this.selectedFiles)
            .subscribe(() => this.selectedFiles = undefined);
        }
        this.resetForm();
        this.loadProducts();
      });
  }

  deleteProduct(id: number) {
    this.adminService.deleteProduct(id)
      .subscribe(() => this.loadProducts());
  }

  deleteImage(img: ProductImage) {
    this.adminService.deleteProductImage(img.imageID)
      .subscribe(() => {
        this.currentImages =
          this.currentImages.filter(i => i.imageID !== img.imageID);
        if (this.selectedPrimaryImageId === img.imageID) {
          this.selectedPrimaryImageId = null;
        }
      });
  }

  resetForm() {
    this.form = {
      name:           '',
      description:    '',
      price:          0,
      stockQuantity:  0,
      productTypeID:  null,
      primaryImageID: null
    };
    this.selectedFiles          = undefined;
    this.currentImages          = [];
    this.selectedPrimaryImageId = null;
    this.isEditMode             = false;
    this.editingProductId       = null;
  }
}
