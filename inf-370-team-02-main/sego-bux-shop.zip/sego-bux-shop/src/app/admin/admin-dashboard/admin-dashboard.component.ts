import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-dashboard.component.html',  // ✅ correct filename
  styleUrls: ['./admin-dashboard.component.scss'],  // ✅ correct filename
})
export class DashboardComponent {}
