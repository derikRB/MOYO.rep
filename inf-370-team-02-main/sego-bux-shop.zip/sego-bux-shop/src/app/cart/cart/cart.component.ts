import { Injectable } from '@angular/core';

export interface CartItem {
  productId: number;
  name: string;
  price: number;
  quantity: number;
  imageUrl?: string;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private items: CartItem[] = [];

  addToCart(item: CartItem): void {
    const index = this.items.findIndex(i => i.productId === item.productId);
    if (index !== -1) {
      this.items[index].quantity += item.quantity;
    } else {
      this.items.push(item);
    }
  }

  getItems(): CartItem[] {
    return this.items;
  }

  removeItem(productId: number): void {
    this.items = this.items.filter(item => item.productId !== productId);
  }

  clearCart(): void {
    this.items = [];
  }
}
