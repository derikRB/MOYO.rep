import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CartService, CartItem } from '../../services/cart.service';
import { OrderService, OrderDto } from '../../services/order.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {
  cartItems: CartItem[] = [];
  deliveryForm!: FormGroup;
  total = 0;
  vat = 0;
  grandTotal = 0;
  customerId = 0;

  constructor(
    private fb: FormBuilder,
    private cartService: CartService,
    private orderService: OrderService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const token = this.authService.getToken();
    if (!token) {
      this.router.navigate(['/login']);
      return;
    }

    const payload = JSON.parse(atob(token.split('.')[1]));
    this.customerId = +payload.nameid;

    this.cartItems = this.cartService.getItems();
    this.total = this.cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    this.vat = this.total * 0.15;
    this.grandTotal = this.total + this.vat;

    this.deliveryForm = this.fb.group({
      name: ['', Validators.required],
      surname: ['', Validators.required],
      phone: ['', Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      suburb: ['', Validators.required],
      province: ['', Validators.required],
      postalCode: ['', Validators.required]
    });
  }

  getTotal(): number {
    return this.cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }

  placeOrder(): void {
    if (this.deliveryForm.invalid) return;

    const orderDto: OrderDto = {
      CustomerID: this.customerId,
      OrderStatusID: 1, // "Pending"
      TotalPrice: this.getTotal(),
      OrderLines: this.cartItems.map(item => ({
        ProductID: item.productId,
        Quantity: item.quantity
      }))
    };

    this.orderService.placeOrder(orderDto).subscribe({
      next: () => {
        alert('Order placed successfully!');
        this.cartService.clearCart();
        this.router.navigate(['/profile']);
      },
      error: () => alert('Failed to place order.')
    });
  }
}
