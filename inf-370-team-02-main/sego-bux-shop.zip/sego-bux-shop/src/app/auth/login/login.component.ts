// src/app/auth/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  loginError = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      identifier: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onLogin(): void {
    this.loginError = '';

    if (this.loginForm.valid) {
      const credentials = this.loginForm.value;
      const payload = {
        emailOrUsername: credentials.identifier,
        password: credentials.password
      };

      this.authService.loginAuto(payload).subscribe({
        next: () => {
          const role = this.authService.getRoleFromToken();
          console.log('Logged in as:', role);

          if (role === 'Customer') {
            this.router.navigate(['/products']);
          } else if (role === 'Employee' || role === 'Admin' || role === 'Manager') {
            this.router.navigate(['/admin']);
          } else {
            this.router.navigate(['/']); // fallback
          }
        },
        error: (err) => {
          this.loginError = 'Login failed: ' + (err.error?.message || err.message || 'Unknown error');
          console.error('Login failed:', err);
        }
      });
    } else {
      this.loginForm.markAllAsTouched();
    }
  }
}
