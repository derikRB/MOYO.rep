import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface CustomizationDto {
  orderLineID: number;
  template: string;
  customText: string;
  font: string;
  fontSize: number;
  color: string;
  uploadedImagePath: string;
}

@Injectable({
  providedIn: 'root'
})
export class CustomizationService {
  private apiUrl = 'https://localhost:5001/api/customization';

  constructor(private http: HttpClient) {}

  addCustomization(dto: CustomizationDto): Observable<any> {
    return this.http.post(this.apiUrl, dto);
  }

  updateCustomization(orderLineID: number, dto: CustomizationDto): Observable<any> {
    return this.http.put(`${this.apiUrl}/${orderLineID}`, dto);
  }

  deleteCustomization(orderLineID: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${orderLineID}`);
  }

  getByOrderLine(orderLineID: number): Observable<CustomizationDto> {
    return this.http.get<CustomizationDto>(`${this.apiUrl}/${orderLineID}`);
  }
}
