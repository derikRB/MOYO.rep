import { Injectable } from '@angular/core';

export interface CartItem {
  productId: number;
  name: string;
  price: number;
  quantity: number;
  imageUrl?: string;
  customization?: {
    template?: string;
    customText?: string;
    font?: string;
    fontSize?: number;
    color?: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private items: CartItem[] = [];

  constructor() {
    const saved = localStorage.getItem('cart');
    this.items = saved ? JSON.parse(saved) : [];
  }

  private save(): void {
    localStorage.setItem('cart', JSON.stringify(this.items));
  }

  private getItemKey(item: CartItem): string {
    const customKey = item.customization ? JSON.stringify(item.customization) : 'no-custom';
    return `${item.productId}-${item.name}-${item.price}-${customKey}`;
  }

  addToCart(newItem: CartItem): void {
    const key = this.getItemKey(newItem);
    const index = this.items.findIndex(i => this.getItemKey(i) === key);

    if (index !== -1) {
      this.items[index].quantity += newItem.quantity;
    } else {
      this.items.push({ ...newItem });
    }
    this.save();
  }

  getItems(): CartItem[] {
    return [...this.items];
  }

  removeItem(item: CartItem): void {
    const key = this.getItemKey(item);
    const index = this.items.findIndex(i => this.getItemKey(i) === key);
    
    if (index !== -1) {
      this.items.splice(index, 1);
      this.save();
    }
  }

  increaseQuantity(item: CartItem): void {
    const key = this.getItemKey(item);
    const index = this.items.findIndex(i => this.getItemKey(i) === key);
    
    if (index !== -1) {
      this.items[index].quantity++;
      this.save();
    }
  }

  decreaseQuantity(item: CartItem): void {
    const key = this.getItemKey(item);
    const index = this.items.findIndex(i => this.getItemKey(i) === key);
    
    if (index !== -1) {
      this.items[index].quantity--;
      if (this.items[index].quantity <= 0) {
        this.removeItem(item);
      } else {
        this.save();
      }
    }
  }

  updateCustomization(oldItem: CartItem, newCustomization: any): void {
    const key = this.getItemKey(oldItem);
    const index = this.items.findIndex(i => this.getItemKey(i) === key);
    
    if (index !== -1) {
      const updatedItem = {
        ...this.items[index],
        customization: newCustomization
      };
      
      this.items.splice(index, 1);
      this.items.push(updatedItem);
      this.save();
    }
  }

  getSubtotal(): number {
    return this.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }

  getVATAmount(): number {
    return this.getSubtotal() * 0.15;
  }

  getTotalWithVAT(): number {
    return this.getSubtotal() + this.getVATAmount();
  }

  clearCart(): void {
    this.items = [];
    localStorage.removeItem('cart');
  }
}