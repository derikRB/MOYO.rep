import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CartItem } from './cart.service'; // make sure path is correct

export interface OrderDto {
  CustomerID: number;
  OrderStatusID: number;
  TotalPrice: number;
  OrderLines: {
    ProductID: number;
    Quantity: number;
  }[];
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private apiUrl = 'https://localhost:7025/api/order';

  constructor(private http: HttpClient) {}

// OrderService.ts

placeOrder(dto: OrderDto): Observable<any> {
  return this.http.post(`${this.apiUrl}/place`, dto);
}


  updateOrder(orderId: number, dto: OrderDto): Observable<any> {
    return this.http.put(`${this.apiUrl}/${orderId}`, dto);
  }

  cancelOrder(orderId: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/${orderId}/cancel`, {});
  }
}
