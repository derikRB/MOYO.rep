import { Injectable } from '@angular/core';
import emailjs, { EmailJSResponseStatus } from '@emailjs/browser';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  private userID = environment.emailJsUserId;
private serviceID = environment.emailJsServiceId;
private templateID = environment.emailJsTemplateId;


  constructor() {}

  sendContactEmail(data: { from_name: string; from_email: string; phone?: string; message: string; }): Promise<EmailJSResponseStatus> {
    return emailjs.send(
      this.serviceID,
      this.templateID,
      data,
      this.userID
    );
  }
}
