// src/app/services/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, catchError, tap } from 'rxjs';
import { of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = 'https://localhost:7025/api/Auth';

  private loggedIn = new BehaviorSubject<boolean>(!!this.getToken());
  isLoggedIn$ = this.loggedIn.asObservable();

  private roleSubject = new BehaviorSubject<string | null>(this.getRoleFromToken());
  role$ = this.roleSubject.asObservable();

  constructor(private http: HttpClient) {}

  /**
   * Tries employee login first, if it fails, tries customer login.
   */
  loginAuto(data: { emailOrUsername: string; password: string }) {
    return this.http.post<{ token: string; refreshToken: string }>(`${this.apiUrl}/employee/login`, data).pipe(
      tap(response => this.handleLoginSuccess(response)),
      catchError(() =>
        this.http.post<{ token: string; refreshToken: string }>(`${this.apiUrl}/customer/login`, data).pipe(
          tap(response => this.handleLoginSuccess(response))
        )
      )
    );
  }

  register(data: any) {
    return this.http.post<{ token: string; refreshToken: string }>(
      `${this.apiUrl}/customer/register`,
      data
    ).pipe(
      tap(response => this.handleLoginSuccess(response))
    );
  }

  private handleLoginSuccess(response: { token: string; refreshToken: string }) {
    this.saveToken(response.token);
    this.loggedIn.next(true);
    const role = this.getRoleFromToken();
    this.roleSubject.next(role);
    if (role) localStorage.setItem('userRole', role);
  }

  saveToken(token: string) {
    localStorage.setItem('token', token);
    const role = this.getRoleFromToken();
    if (role) localStorage.setItem('userRole', role);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getRoleFromToken(): string | null {
    const token = localStorage.getItem('token');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const roleClaim = payload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
      return Array.isArray(roleClaim) ? roleClaim[0] : roleClaim;
    } catch {
      return null;
    }
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');
    this.loggedIn.next(false);
    this.roleSubject.next(null);
  }

  getUserRole(): string | null {
    return localStorage.getItem('userRole');
  }
}
