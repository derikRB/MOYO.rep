import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError }  from 'rxjs';
import { catchError }              from 'rxjs/operators';
import { Product }                from '../models/product.model';
import { ProductImage }           from '../models/product-image.model';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private apiUrl     = 'https://localhost:7025/api/product';
  private imagesBase = 'https://localhost:7025';  // host only

  constructor(private http: HttpClient) {}

  getProducts(): Observable<Product[]> {
    const token   = localStorage.getItem('token') || '';
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });

    return this.http.get<Product[]>(this.apiUrl, { headers }).pipe(
      catchError(err => {
        console.error('Failed to load products', err);
        return throwError(() => new Error('Failed to load products'));
      })
    );
  }

  /** Build a full URL to an imageUrl returned by the API */
  imageFullUrl(image: ProductImage): string {
    // backend returns imageUrl = "/images/products/abc.png"
    return this.imagesBase + image.imageUrl;
  }
}
