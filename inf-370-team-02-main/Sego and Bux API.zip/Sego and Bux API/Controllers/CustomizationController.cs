﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Sego_and__Bux.DTOs;
using Sego_and__Bux.Interfaces;
using Sego_and__Bux.Models;
using Sego_and__Bux.Services;

namespace Sego_and__Bux.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Customer")]
    public class CustomizationController : ControllerBase
    {
        private readonly ICustomizationService _customizationService;
        public CustomizationController(ICustomizationService customizationService) => _customizationService = customizationService;

        [HttpPost]
        public async Task<IActionResult> Add(CustomizationDto dto) => Ok(await _customizationService.AddCustomizationAsync(dto));

        [HttpGet("{orderLineId}")]
        public async Task<IActionResult> GetByOrderLine(int orderLineId) => Ok(await _customizationService.GetByOrderLineIdAsync(orderLineId));

        [HttpPut("{orderLineId}")]
        public async Task<IActionResult> Update(int orderLineId, CustomizationDto dto) => Ok(await _customizationService.UpdateCustomizationAsync(orderLineId, dto));

        [HttpDelete("{orderLineId}")]
        public async Task<IActionResult> Delete(int orderLineId) => Ok(await _customizationService.DeleteCustomizationAsync(orderLineId));
    }
}

