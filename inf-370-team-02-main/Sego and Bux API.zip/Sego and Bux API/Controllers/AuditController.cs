﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Sego_and__Bux.DTOs;
using Sego_and__Bux.Interfaces;
using Sego_and__Bux.Models;
using Sego_and__Bux.Services;

namespace Sego_and__Bux.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Employee")]
    public class AuditController : ControllerBase
    {
        private readonly IAuditService _auditService;
        public AuditController(IAuditService auditService) => _auditService = auditService;

        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _auditService.GetAllLogsAsync());

        [HttpGet("{userId}")]
        public async Task<IActionResult> GetByUser(int userId) => Ok(await _auditService.GetLogsByUserIdAsync(userId));
    }
}
