﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Sego_and__Bux.DTOs;
using Sego_and__Bux.Interfaces;
using Sego_and__Bux.Models;

namespace Sego_and__Bux.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Manager,Employee")]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoryService;
        public CategoryController(ICategoryService categoryService) => _categoryService = categoryService;

        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _categoryService.GetAllCategoriesAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id) => Ok(await _categoryService.GetCategoryByIdAsync(id));

        [HttpPost]
        public async Task<IActionResult> Create(CategoryDto dto) => Ok(await _categoryService.AddCategoryAsync(dto));

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, CategoryDto dto) => Ok(await _categoryService.UpdateCategoryAsync(id, dto));

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id) => Ok(await _categoryService.DeleteCategoryAsync(id));
    }

}
