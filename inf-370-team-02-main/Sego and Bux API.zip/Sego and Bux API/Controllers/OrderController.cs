﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Sego_and__Bux.DTOs;
using Sego_and__Bux.Interfaces;
using Sego_and__Bux.Models;

namespace Sego_and__Bux.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Customer")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;
        public OrderController(IOrderService orderService) => _orderService = orderService;

        [HttpPost("place")]
        public async Task<IActionResult> PlaceOrder([FromBody] OrderDto dto)
        {
            if (dto == null)
                return BadRequest("Order data is missing.");

            if (dto.CustomerID <= 0 || dto.OrderLines == null || !dto.OrderLines.Any())
                return BadRequest("Invalid order data.");

            try
            {
                var result = await _orderService.PlaceOrderAsync(dto);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Failed to place order", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrder(int id) => Ok(await _orderService.GetOrderByIdAsync(id));

        [HttpGet("customer/{customerId}")]
        public async Task<IActionResult> GetByCustomer(int customerId) => Ok(await _orderService.GetOrdersByCustomerAsync(customerId));

        [HttpPut("{orderId}/cancel")]
        public async Task<IActionResult> Cancel(int orderId) => Ok(await _orderService.CancelOrderAsync(orderId));

        [HttpPut("{orderId}")]
        public async Task<IActionResult> UpdateOrder(int orderId, [FromBody] OrderDto dto)
        {
            var result = await _orderService.UpdateOrderAsync(orderId, dto);
            return result == null ? BadRequest("Cannot update this order.") : Ok(result);
        }

        [HttpPut("{orderId}/status/{newStatusId}")]
        [Authorize(Roles = "Employee")]
        public async Task<IActionResult> UpdateStatus(int orderId, int newStatusId) =>
            Ok(await _orderService.UpdateOrderStatusAsync(orderId, newStatusId));
    }
}
