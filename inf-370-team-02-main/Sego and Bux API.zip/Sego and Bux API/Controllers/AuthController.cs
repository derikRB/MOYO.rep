﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Sego_and__Bux.DTOs;
using Sego_and__Bux.Interfaces;
using Sego_and__Bux.Helpers;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using Sego_and__Bux.Services;

namespace Sego_and__Bux.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ICustomerService _customerService;
        private readonly IEmployeeService _employeeService;
        private readonly IJwtService _jwtService;
        private readonly IRefreshTokenStore _refreshTokenStore;

        public AuthController(
            ICustomerService customerService,
            IEmployeeService employeeService,
            IJwtService jwtService,
            IRefreshTokenStore refreshTokenStore)
        {
            _customerService = customerService;
            _employeeService = employeeService;
            _jwtService = jwtService;
            _refreshTokenStore = refreshTokenStore;
        }

        // ------------------------- CUSTOMER REGISTER -------------------------
        [HttpPost("customer/register")]
        public async Task<IActionResult> RegisterCustomer([FromBody] RegisterCustomerDto dto)
        {
            var customer = await _customerService.RegisterAsync(dto);

            var token = _jwtService.GenerateToken(customer.CustomerID.ToString(), new List<string> { "Customer" });
            var refreshToken = _jwtService.GenerateRefreshToken();
            _refreshTokenStore.SaveRefreshToken(customer.CustomerID.ToString(), refreshToken);

            return Ok(new RefreshResponseDto
            {
                Token = token,
                RefreshToken = refreshToken
            });
        }

        // ------------------------- CUSTOMER LOGIN -------------------------
        [HttpPost("customer/login")]
        public async Task<IActionResult> LoginCustomer(LoginDto dto)
        {
            var customer = await _customerService.GetCustomerByUsernameOrEmailAsync(dto.EmailOrUsername);
            if (customer == null || !PasswordHasher.VerifyPassword(dto.Password, customer.PasswordHash))
                return Unauthorized("Invalid credentials");

            var token = _jwtService.GenerateToken(customer.CustomerID.ToString(), new List<string> { "Customer" });

            var refreshToken = _jwtService.GenerateRefreshToken();
            _refreshTokenStore.SaveRefreshToken(customer.CustomerID.ToString(), refreshToken);

            return Ok(new RefreshResponseDto
            {
                Token = token,
                RefreshToken = refreshToken
            });
        }

        // ------------------------- EMPLOYEE LOGIN -------------------------
        [HttpPost("employee/login")]
        public async Task<IActionResult> LoginEmployee(LoginDto dto)
        {
            var employee = (await _employeeService.GetAllEmployeesAsync())
                .FirstOrDefault(e => e.Username == dto.EmailOrUsername || e.Email == dto.EmailOrUsername);

            // NOTE: Password check should ideally use hashing (implement if needed)
            if (employee == null || dto.Password != employee.PasswordHash)
                return Unauthorized("Invalid credentials");

            var token = _jwtService.GenerateToken(employee.EmployeeID.ToString(), new List<string> { employee.Role });

            var refreshToken = _jwtService.GenerateRefreshToken();
            _refreshTokenStore.SaveRefreshToken(employee.EmployeeID.ToString(), refreshToken);

            return Ok(new RefreshResponseDto
            {
                Token = token,
                RefreshToken = refreshToken
            });
        }

        // ------------------------- REFRESH TOKEN -------------------------
        [HttpPost("refresh")]
        public IActionResult Refresh([FromBody] RefreshRequestDto request)
        {
            try
            {
                var principal = _jwtService.GetPrincipalFromExpiredToken(request.Token);
                var userId = principal.FindFirstValue(ClaimTypes.NameIdentifier);
                var roles = principal.FindAll(ClaimTypes.Role).Select(r => r.Value).ToList();

                if (!_refreshTokenStore.ValidateRefreshToken(userId, request.RefreshToken))
                    return Unauthorized("Invalid refresh token");

                var newJwtToken = _jwtService.GenerateToken(userId, roles);
                var newRefreshToken = _jwtService.GenerateRefreshToken();

                _refreshTokenStore.RemoveRefreshToken(userId, request.RefreshToken);
                _refreshTokenStore.SaveRefreshToken(userId, newRefreshToken);

                return Ok(new RefreshResponseDto
                {
                    Token = newJwtToken,
                    RefreshToken = newRefreshToken
                });
            }
            catch (SecurityTokenException)
            {
                return Unauthorized("Invalid token");
            }
        }
    }
}
