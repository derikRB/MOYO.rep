﻿using Sego_and__Bux.Data;
using Sego_and__Bux.DTOs;
using Sego_and__Bux.Interfaces;
using Sego_and__Bux.Models;
using Microsoft.EntityFrameworkCore;

namespace Sego_and__Bux.Services
{
    public class OrderService : IOrderService
    {
        private readonly ApplicationDbContext _context;

        public OrderService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Order> PlaceOrderAsync(OrderDto dto)
        {
            var order = new Order
            {
                CustomerID = dto.CustomerID,
                OrderStatusID = dto.OrderStatusID,
                TotalPrice = dto.TotalPrice,
                OrderDate = DateTime.UtcNow,
                OrderLines = dto.OrderLines.Select(line => new OrderLine
                {
                    ProductID = line.ProductID,
                    Quantity = line.Quantity
                }).ToList()
            };

            _context.Orders.Add(order);

            try
            {
                await _context.SaveChangesAsync();
                return order;
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ EF Save Error: " + ex.InnerException?.Message ?? ex.Message);
                throw;
            }
        }


        public async Task<Order?> GetOrderByIdAsync(int orderId)
        {
            return await _context.Orders
                .Include(o => o.OrderLines)
                .FirstOrDefaultAsync(o => o.OrderID == orderId);
        }

        public async Task<IEnumerable<Order>> GetOrdersByCustomerAsync(int customerId)
        {
            return await _context.Orders
                .Where(o => o.CustomerID == customerId)
                .Include(o => o.OrderLines)
                .ToListAsync();
        }

        public async Task<bool> CancelOrderAsync(int orderId)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null) return false;

            order.OrderStatusID = 3; // Example: 3 = Canceled
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Order?> UpdateOrderAsync(int orderId, OrderDto dto)
        {
            var order = await _context.Orders
                .Include(o => o.OrderLines)
                .FirstOrDefaultAsync(o => o.OrderID == orderId);

            if (order == null || order.OrderStatusID != 1) // Only allow if status = Pending
                return null;

            order.TotalPrice = dto.TotalPrice;
            _context.OrderLines.RemoveRange(order.OrderLines);
            order.OrderLines = dto.OrderLines.Select(x => new OrderLine
            {
                ProductID = x.ProductID,
                Quantity = x.Quantity
            }).ToList();

            await _context.SaveChangesAsync();
            return order;
        }




        public async Task<bool> UpdateOrderStatusAsync(int orderId, int newStatusId)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null) return false;

            order.OrderStatusID = newStatusId;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
