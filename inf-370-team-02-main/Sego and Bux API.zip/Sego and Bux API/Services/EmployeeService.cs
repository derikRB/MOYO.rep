﻿using Sego_and__Bux.Data;
using Sego_and__Bux.DTOs;
using Sego_and__Bux.Helpers;
using Sego_and__Bux.Interfaces;
using Sego_and__Bux.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sego_and__Bux.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly ApplicationDbContext _context;
        public EmployeeService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Employee> RegisterEmployeeAsync(LoginDto dto)
        {
            // Check if username or email exists (depending on your system, adjust accordingly)
            if (await _context.Employees.AnyAsync(e => e.Username == dto.EmailOrUsername || e.Email == dto.EmailOrUsername))
                throw new Exception("Username or email already exists");

            var employee = new Employee
            {
                Username = dto.EmailOrUsername,
                PasswordHash = PasswordHasher.HashPassword(dto.Password)
                // Initialize other fields if needed, e.g. Email = dto.EmailOrUsername if relevant
            };

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return employee;
        }

        public async Task<IEnumerable<Employee>> GetAllEmployeesAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<IEnumerable<Customer>> SearchCustomersAsync(string searchTerm)
        {
            return await _context.Customers
                .Where(c => c.Name.Contains(searchTerm)
                         || c.Surname.Contains(searchTerm)
                         || c.Email.Contains(searchTerm))
                .ToListAsync();
        }

        public async Task<IEnumerable<Employee>> SearchEmployeesAsync(string searchTerm)
        {
            return await _context.Employees
                .Where(e => e.Username.Contains(searchTerm)
                         || (e.Email != null && e.Email.Contains(searchTerm))
                         || (e.Role != null && e.Role.Contains(searchTerm)))
                .ToListAsync();
        }
    }
}
