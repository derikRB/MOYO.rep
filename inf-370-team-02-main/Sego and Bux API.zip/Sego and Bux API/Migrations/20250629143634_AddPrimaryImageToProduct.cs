﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Sego_and__Bux.Migrations
{
    /// <inheritdoc />
    public partial class AddPrimaryImageToProduct : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
