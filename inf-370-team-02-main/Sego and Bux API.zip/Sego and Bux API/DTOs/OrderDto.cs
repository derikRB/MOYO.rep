﻿using Sego_and__Bux.DTOs;

namespace Sego_and__Bux.DTOs;

public class OrderDto
{
    public int CustomerID { get; set; }
    public List<OrderLineDto> OrderLines { get; set; }
    public decimal TotalPrice { get; set; }
    public int OrderStatusID { get; set; }
}

public class OrderLineDto
{
    public int ProductID { get; set; }
    public int Quantity { get; set; }
}



