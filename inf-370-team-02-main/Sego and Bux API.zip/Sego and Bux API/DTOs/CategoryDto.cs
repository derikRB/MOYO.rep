﻿using Sego_and__Bux.DTOs;

namespace Sego_and__Bux.DTOs

{
    public class CategoryDto
    {
        public string CategoryName { get; set; }
        public string Description { get; set; }
    }
}
