﻿using Sego_and__Bux.DTOs;

namespace Sego_and__Bux.DTOs;
    public class EmailRequest
    {
        public string ToEmail { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }

