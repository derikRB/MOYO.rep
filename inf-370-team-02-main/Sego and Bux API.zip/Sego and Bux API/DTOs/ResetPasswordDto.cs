﻿namespace Sego_and__Bux.DTOs
{
    public class ResetPasswordDto
    {
        public int EmployeeID { get; set; }
        public string NewPassword { get; set; } = string.Empty;
    }
}
