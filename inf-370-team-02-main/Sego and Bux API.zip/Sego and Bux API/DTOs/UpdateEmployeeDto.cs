﻿// DTOs/UpdateEmployeeDto.cs
namespace Sego_and__Bux.DTOs
{
    public class UpdateEmployeeDto
    {
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }
}
