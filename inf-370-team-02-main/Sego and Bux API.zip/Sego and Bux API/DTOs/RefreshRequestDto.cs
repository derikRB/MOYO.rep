﻿namespace Sego_and__Bux.DTOs
{
    public class RefreshRequestDto
    {
        public string Token { get; set; }
        public string RefreshToken { get; set; }
    }
}