﻿namespace Sego_and__Bux.DTOs
{
    public class RegisterEmployeeDto
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
