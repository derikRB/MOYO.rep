﻿using Sego_and__Bux.DTOs;

namespace Sego_and__Bux.DTOs;
public class ProductTypeDto
{
    public string ProductTypeName { get; set; } = string.Empty;
    public string Description { get; set; }
    public int CategoryID { get; set; }
}
