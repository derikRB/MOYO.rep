﻿using Microsoft.EntityFrameworkCore;
using Sego_and__Bux.Models;

namespace Sego_and__Bux.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }
       public DbSet<ProductImage> ProductImages { get; set; }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductType> ProductTypes { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderLine> OrderLines { get; set; }
        public DbSet<Customization> Customizations { get; set; }
        public DbSet<OrderStatus> OrderStatuses { get; set; }
        public DbSet<UserActivityLog> UserActivityLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ✅ Set primary key for UserActivityLog
            modelBuilder.Entity<UserActivityLog>()
                .HasKey(log => log.AuditID);

            // ✅ Order relationships
            modelBuilder.Entity<Order>()
                .HasMany(o => o.OrderLines)
                .WithOne(ol => ol.Order)
                .HasForeignKey(ol => ol.OrderID);

            modelBuilder.Entity<OrderLine>()
                .HasOne(ol => ol.Customization)
                .WithOne(c => c.OrderLine)
                .HasForeignKey<Customization>(c => c.OrderLineID);

            modelBuilder.Entity<ProductType>()
                .HasOne(pt => pt.Category)
                .WithMany()
                .HasForeignKey(pt => pt.CategoryID);

            modelBuilder.Entity<Product>()
                .HasOne(p => p.ProductType)
                .WithMany()
                .HasForeignKey(p => p.ProductTypeID);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.OrderStatus)
                .WithMany()
                .HasForeignKey(o => o.OrderStatusID);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.Customer)
                .WithMany()
                .HasForeignKey(o => o.CustomerID);

            // one‐to‐many Product → ProductImages
            // ── existing mappings ──
            modelBuilder.Entity<Product>()
                .HasMany(p => p.ProductImages)
                .WithOne(pi => pi.Product)
                .HasForeignKey(pi => pi.ProductID);

            modelBuilder.Entity<Product>()
                .HasOne(p => p.PrimaryImage)
                .WithMany()
                .HasForeignKey(p => p.PrimaryImageID)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<ProductImage>()
                .HasKey(pi => pi.ImageID);

        }
    }
}
