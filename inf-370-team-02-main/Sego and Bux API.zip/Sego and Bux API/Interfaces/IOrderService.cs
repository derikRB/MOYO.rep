﻿using Sego_and__Bux.DTOs;
using Sego_and__Bux.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IOrderService
{
    Task<Order> PlaceOrderAsync(OrderDto dto);
    Task<Order> GetOrderByIdAsync(int id);
    Task<IEnumerable<Order>> GetOrdersByCustomerAsync(int customerId);
    Task<bool> CancelOrderAsync(int orderId);
    Task<Order?> UpdateOrderAsync(int orderId, OrderDto dto); // <-- Add this line
    Task<bool> UpdateOrderStatusAsync(int orderId, int newStatusId);
}
