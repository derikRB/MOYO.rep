﻿using Sego_and__Bux.DTOs;
using Sego_and__Bux.Models;
using System.Threading.Tasks;

namespace Sego_and__Bux.Interfaces
{
    public interface ICustomerService
    {
        Task<Customer?> GetCustomerByUsernameOrEmailAsync(string emailOrUsername);
        Task<Customer> RegisterAsync(RegisterCustomerDto registerDto);
        Task<CustomerDto?> GetCustomerByIdAsync(int id);
        Task<Customer?> UpdateCustomerAsync(int id, UpdateCustomerDto dto);
        Task<bool> DeleteCustomerAsync(int id);
        Task SaveChangesAsync();

        // ✅ Match this exactly in your implementation
        Task<bool> UpdatePasswordAsync(int id, string currentPassword, string newPassword);
    }
}
