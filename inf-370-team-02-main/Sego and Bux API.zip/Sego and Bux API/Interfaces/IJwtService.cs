﻿using System.Collections.Generic;
using System.Security.Claims;

namespace Sego_and__Bux.Interfaces
{
    public interface IJwtService
    {
        string GenerateToken(string userId, IList<string> roles);
        string GenerateRefreshToken();
        ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    }
}
