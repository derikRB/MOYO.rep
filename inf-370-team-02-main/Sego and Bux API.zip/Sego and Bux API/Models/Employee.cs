﻿namespace Sego_and__Bux.Models
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string Email { get; set; } = string.Empty;     // ✅ Add
        public string Role { get; set; } = "Employee";        // ✅ Add
    }
}
